package com.ctsi.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ctsi.entity.TbUser;

/**
 * @ClassName : TbUserMapper
 * @Description :
 * @Author : Xiaotianyu  //作者
 * @Date: 2020-12-07 17:29
 */
public interface TbUserMapper extends BaseMapper<TbUser> {
}
